public class ImplementorC extends Processor{
    public ImplementorC() {
        super();
    }
    public boolean process1() {
        return false;
    }
    public boolean process2() {
        return false;
    }
    public void process3(){
        System.out.println("Implementor C running process 3.");
    }
    public void process4(){
        System.out.println("Implementor C running process 4.");
    }
    public void process5(){
        System.out.println("Implementor C running process 5.");
    }

}

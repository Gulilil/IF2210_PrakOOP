#include "DepreciatingAsset.hpp"
#include "AppreciatingAsset.hpp"
#include "BaseAsset.hpp"
#include "Asset.hpp"
#include <iostream>
using namespace std;

int main () {
    // AppreciatingAsset a(500, 5);
    // DepreciatingAsset b(500,5);

    // cout << a.getValue(6) << endl;
    // cout << b.getValue(6) << endl;
    // BaseAsset *bA = new BaseAsset(500);
    // cout << bA->getValue(5) << endl;
    // Asset *a = new Asset();
    // DepreciatingAsset *dA = new DepreciatingAsset(*a, 5.0);
    // AppreciatingAsset *aA = new AppreciatingAsset(*a, 5.0);
    return 0;
}
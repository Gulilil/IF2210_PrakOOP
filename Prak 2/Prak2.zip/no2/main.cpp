#include "BurnableBarrel.hpp"
#include "ExplodableBarrel.hpp"

int main (){
    BurnableBarrel bb;

    return 0;
}
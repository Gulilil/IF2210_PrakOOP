public interface Taxable {
    public double calculateTax();
}
